from django.urls import path, include
from . import views


urlpatterns = [
    path("dashboard", views.Dashboard, name="Dashboard"),
    path("pengawastps", views.UserPengawasTPSView, name="UserPengawasTPSView"),
]
