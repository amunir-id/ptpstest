from django.apps import AppConfig


class CalegConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'caleg'
