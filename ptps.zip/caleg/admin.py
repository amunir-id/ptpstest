from django.contrib import admin

# from caleg.models import Caleg

# # Register your models here.
# admin.site.register(Caleg)