from django.apps import AppConfig


class DaftarPemilihConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'daftar_pemilih'
