from django.apps import AppConfig


class PemilihanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pemilihan'
