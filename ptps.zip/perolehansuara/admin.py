from django.contrib import admin

from perolehansuara.models import (
    HasilPpwp,
    DataPemilihPenggunaHakPilihPpwp,
    DataPenggunaSuratSuaraPpwp,
    DataDisabilitasPpwp,
    DataSuaraSahdanTidakSahPpwp,
)


@admin.register(HasilPpwp)
class HasilPpwpAdmin(admin.ModelAdmin):
    list_display = ("__str__",)


@admin.register(DataPemilihPenggunaHakPilihPpwp)
class DataPemilihPenggunaHakPilihPpwpAdmin(admin.ModelAdmin):
    list_display = ("__str__",)


@admin.register(DataPenggunaSuratSuaraPpwp)
class DataPenggunaSuratSuaraPpwpAdmin(admin.ModelAdmin):
    list_display = ("__str__",)


@admin.register(DataDisabilitasPpwp)
class DataDisabilitasPpwpAdmin(admin.ModelAdmin):
    list_display = ("__str__",)


@admin.register(DataSuaraSahdanTidakSahPpwp)
class DataSuaraSahdanTidakSahPpwpAdmin(admin.ModelAdmin):
    list_display = ("__str__",)
