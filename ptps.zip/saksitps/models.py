from django.db import models

from accounts.models import User
from wilayah.models import Kecamatan, KelDesa

# Create your models here.
