from django.urls import path, include
from . import views


urlpatterns = [
    path("dashboard", views.Dashboard, name="Dashboard"),
    path("end-report", views.EndReportView, name="EndReportView"),
    path("start-report", views.StartReportView, name="StartReportView"),
    path("whether-report", views.WhetherReportView, name="WhetherReportView"),
    path("lhp", views.LhpView, name="LhpView"),
    path("lhp-tambah", views.LhpAddView, name="LhpAddView"),
    path("lhp-hapus/<int:pk>", views.LhpDeleteView, name="LhpDeleteView"),
    path(
        "perolehan/presiden", views.PerolehanPresidenView, name="PerolehanPresidenView"
    ),
    path("profile-saya", views.UserProfileView, name="UserProfileView"),
    path("profile-saya/pengaturan", views.Settings, name="Settings"),
]
