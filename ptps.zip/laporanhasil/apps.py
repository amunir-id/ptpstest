from django.apps import AppConfig


class LaporanhasilConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'laporanhasil'
