from django.apps import AppConfig


class PesertaPemiluConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'peserta_pemilu'
